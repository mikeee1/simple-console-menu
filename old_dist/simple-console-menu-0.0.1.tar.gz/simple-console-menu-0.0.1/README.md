# Simple console menu
this is a simple console menu